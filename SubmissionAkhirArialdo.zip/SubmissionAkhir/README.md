### SUBMISSION KELAS ANDROID PEMULA to DICODING ###
Selamat Malam Code Reviewer Dicoding
Submission ini dibuat untuk memenuhi tugas akhir di Kelas Android Pemula
Project ini dikerjakan sepenuhnya oleh Arialdo Rivandi Tion Saputra (Ivan)
Lama Mengerjakan Project ini sekitar 36 Jam