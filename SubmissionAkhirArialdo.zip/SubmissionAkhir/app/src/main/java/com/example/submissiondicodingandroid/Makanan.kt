package com.example.submissiondicodingandroid

data class Makanan (
    var name : String = "",
    var photo: Int = 0,
    var description: String = ""
)
